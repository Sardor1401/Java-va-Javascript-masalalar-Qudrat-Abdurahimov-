let x = 3;
let y = 5;
let oq = (x + y) % 2 == 0;
console.log(oq);