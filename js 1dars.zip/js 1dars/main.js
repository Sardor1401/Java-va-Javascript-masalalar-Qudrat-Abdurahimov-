//begin 1;
//let a = 4;
//let p = 4*a;
//console.log(p);

//begin 2;
//let a = 4;
//let s = a**2;
//console.log(s);

//begin 3;
//let a = 9;
//let b = 6;
//let s =  a*b;
//let p = 2*(a+b);
//console.log(s,p);

//begin 4;
//let d = 3;
//let pi = 3.14;
//let l = pi*d;
//console.log(l);

//begin 5;
//let a =2;
//let v = a**3;
//let s = 6*a**2;
//console.log(v,s);

//begin 6;
//let a = 3;
//let b = 4;
//let c = 2;
//let v = a*b*c;
//let s = (a*b+b*c+a*c);
//console.log(v,s);

//begin 7;
//let r = 2;
//let pi = 3.14;
//let l = 2*pi*r;
//let s = pi*r**2;
//console.log(l,s);

//begin 8;
//let a = 2;
//let b = 3;
//let t = (a+b)/2;
//console.log(t);

//begin 9;
//let a = 9;
//let b = 4;
// s = (Math.sqrt(4*9))/2;
//console.log(s);

//begin 10;
//let a = 2;
//let b = 3;
// t = a+b;
//let s = a*b;
//let p1 = a**2;
//let p2 = b**2;
//console.log(t,s,p1,p2);

//begin 11;
//let a = 2;
//let b = 3;
//let t = a+b;
//let s = a*b;
//let p1 = Math.abs(a);
//let p2 = Math.abs(b);
//console.log(t,s,p1,p2);

//begin 12;
//let a = 3;
//let b = 4;
//let c = Math.sqrt(a**2+b**2);
//let p = a+b+c;
//console.log(c,p);

//begin 13;
//let r1 = 5;
//let r2 = 3;
//let pi = 3.14;
//let s1 = pi*r1;
//let s2 = pi*r2;
//let s3 = pi*(r1-r2);
//console.log(s1,s2,s3);

//begin 14;
//let l = 10;
//let pi = 3.14;
//let r = l/(2*pi);
//let s = pi*r**2;
//console.log(r,s);

//begin 15;
//let s = 25;
//let pi = 3.14;
//let r = Math.sqrt(s/pi);
//let d = 2*r;
//console.log(r,d);

//begin 16;
//let x1 = 5;
//let x2 = 3;
//let t= Math.abs(x1-x2);
//console.log(t);

//begin 17;
//let a = 5;
//let b = 3;
//let c = 15;
//let s1 = Math.abs(a-c);
//let s2 = Math.abs(b-c);
//let s3 = s1+s2;
//console.log(s1,s2,s3);

//begin 18;
//let a = 4;
//let c = 8;
//let b = 17;
// s1 = Math.abs(a-c);
//let s2 = Math.abs(b-c);
//let p = s1*s2;
//console.log(s1,s2,p);

//begin 19;
//let x1 = 4;
//let x2 = -6;
//let y1 = 4;
//let y2 = -8;
//let s = (Math.abs(x1-x2)*Math.abs(y1-y2));
//console.log(s);

//begin 20;
//let x1 = 3;
//let x2 = 4;
//let y1 = 5;
//let y2 = 7;
//let s = Math.sqrt((x1-x2)**2+(y1-y2)**2);
//console.log(s);

//begin 21;
//let x1 = 3;
//let x2 = 4;
//let x3 = 2;
//let y1 = 5;
//let y2 = 3;
//let y3 = 8;
//let a = Math.sqrt((x1-x2)**2+(y1-y2)**2);
//let b = Math.sqrt((x2-x3)**2+(y2-y3)**2);
//let c = Math.sqrt((x1-x3)**2+(y1-y3)**2);
//let p = (a+b+c)/2;
//let s = Math.sqrt(p*(p-a)*(p-b)*(p-c));
//console.log(a,b,c,p,s);

//begin 22;
//let a = 3;
// b = 4;
//c=a;
//a=b;
//b=c;
//console.log(b,a);

//begin 23;
//let a = 3;
//let b = 4;
//let c = 2;
//x=a;
//a=b;
//b=c;
//=x;
//console.log(a,b,c);

//begin 24;
//let a = 5;
//let b = 6;
//let c = 2;
//x=a;
//a=c;
//c=b;
//b=x;
//console.log(a,b,c);

//begin 25;
//let x = 3;
//let y = 3*x**6-6*x**2-7;
//console.log(y);

//begin 26;
// x = 2;
//let y = 4*(x-3)**6-7*(x-3)**3+2;
//console.log(y);

//begin 27;
//let a = 2;
//let p1 = a**2;
//let p2 = p1*a**2;
//let p3 = p2*a**4;
//console.log(p1,p2,p3);

//begin 28;
//let a = 2;
//let p1 = a**2;
//let p2 = p1*a;
//let p3 = p2*a**2;
//let p4 = p3*a**5;
//let p5 = p4*a**5;
//console.log(p1,p2,p3,p4,p5);

//begin 29;
//let a = 30;
//let pi = 3.14;
//let r = (pi/6)*(180/pi);
//console.log(r);

//begin 30;
//let r = 100;
// pi = 3.14;
//let a = r*(pi/180);
//console.log(a);

//begin 31;
//let tf = 300;
//let tc = (tf-32)/(5/9);
//console.log(tc);

//begin 32;
//let tc = 100;
//let tf =(9*tc/5)+32;
//console.log(tf);

//begin 33;
//let x = 2;
//let y = 4;
//let a = 1000;
//let a1 = a/x;
//let a2 = y*a1;
//console.log(a1,a2);

//begin 34;
//let x = 3;
//let a = 3000;
//let y = 4;
//let b = 2800;
//let a1 = a/x;
//let b1 = b/y;
//console.log(a1,b1);

//begin 35;
//let v = 300;
//let u = 200;
//let t1 = 2;
//let t2 = 3;
//let s1 = (v+u)*t1;
//let s2 = (v-u)*t2;
//let s = s1+s2;
//console.log(s);

//begin 36;
//let v1 = 100;
//let v2 = 200;
//let t = 2;
//let s = 500;
// s1 = (v1+v2)*t+s;
//console.log(s1);

//begin 37;
//let v1 = 200;
//let v2 = 100;
//let s = 400;
//let t = 0.5;
//let s1 = s-(v1+v2)*t;
//console.log(s1);

//begin 38;
//let a = 200;
//let b = 100;
//let x = -b/a;
//console.log(x);

//begin 39;
//let a = 1;
//let b = 3;
//let c = 2;
//let d = b**2-4*a*c;
//let x1 = (-b+Math.sqrt(d))/(2*a);
//let x2 = (-b-Math.sqrt(d))/(2*a);
//console.log(d,x1,x2);

//begin 40;
//let a1 = 3;
//let a2 = 4;
//let b1 = 2;
//let b2 = 5;
//let c1 = 3;
//let c2 = 5;
//let d = (a1*b2-a2*b1);
//let x = (c1*b2-c2*b1)/d;
//let y = (a1*c2-a2*c2)/d;
//console.log(d,x,y);
