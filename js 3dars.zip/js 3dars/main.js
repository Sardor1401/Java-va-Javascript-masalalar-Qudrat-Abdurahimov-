//Boolean 1;
//let a = 4;
//let t = a > 0;
//console.log(t);


//Boolean 2;
//let a = 7;
//let b = a % 2 == 1;
//console.log(b);


//Boolean 3;
//let a = 4;
//let b = a % 2 ==0;
//console.log(b);


//Boolean 4;
//let a = 3;
//let b = 2;
//let d = a > 2 && b <= 3;
//console.log(d,);


//Boolean 5;
//let a = 3;
//let b = -3;
//let d = a >= 0 || b < -2;
//console.log(d);


//Boolean 6;
//let a = 5;
//let b = 4;
//let c = 3;
//let d = (a >= b && b >= c);
//console.log(d);


//Boolean 7;
//let a = 8;
//let b = 5;
//let c = 6;
//let d = a > b &&  c > b;
//console.log(d);


//Boolean 8;
//let a = 9;
//let b = 3;
//let c = a % 2 == 1 && b % 2 == 1;
//console.log(c);


//Boolean 9;
//let a = 9;
//let b = 4;
//let c = a % 2 == 1 &&  b % 2 == 0;
//console.log(c);


//Boolean 10;
//let a = 7;
//let b = 2;
//let c = a % 2 == 1 &&  b % 2 == 0;
//console.log(c);


//Boolean 11;
//let a = 2;
//let b = 4;
//let c = a % 2 == 0 && b % 2 ==0;
//console.log(c);


//Boolean 12;
//let a = 2;
//let b = 4;
//let c = 5;
//let d = a > 0 && b > 0 && c > 0;
//console.log(d);


//Boolean 13;
//let a = 2;
//let b = 4;
//let c = -5;
//let d = a > 0 && b > 0 && c < 0;
//console.log(d);


//Boolean 14;
//let a = 2;
//let b = -3;
//let c = -6;
//let d = a > 0 && b < 0 && c < 0;
//console.log(d);


//Boolean 15;
//let a = 4;
//let b = 7;
//let c = -1;
//let d = a > 0 && b > 0 && c < 0;
//console.log(d);


//Boolean 16;
//let a = 32;
//let b = a % 2 ==0;
//console.log(b);


//Boolean 17;
//let a = 123;
//let b = a % 2 ==1;
//console.log(b);


//Boolean 18;
//let a = 2;
//let b = 2;
//let c = 3;
//let d = a == b && c != (a && b);
//console.log(d);


//Boolean 19;
//let a = 2;
//let b = -2;
//let c = 7;
//let d = c > 0 && a == -b;
//console.log(d);


//Boolean 20;
//let a = 234;
//let b = parseInt(a / 100);
//let c = parseInt(a / 10)%10;
//let d = parseInt(a % 10);
//let k = (b != c && c != d && b != d);
//console.log(k);


//Boolean 21;
//let a = 234;
//let b = parseInt(a / 100);
//let c = parseInt(a / 10)%10;
//let d = parseInt(a % 10);
//let k = b <= c && c <= d;
//console.log(k);


//Boolean 22;
//let a = 567;
//let b = parseInt(a / 100);
//let c = parseInt(a / 10)%10;
//let d = parseInt(a % 10);
//let t = b <= c && c <= d;
//let k = d >= c && c >= b;
//let m = t || k;
//console.log(m);


//Boolean 23;
//let a = 121;
//let b = parseInt(a / 100);
//let c = parseInt(a / 10)%10;
//let d = parseInt(a % 10);
//let m = b == d && b == d != c;
//console.log(m);


//Boolean 24;
//let a = -1;
//let b = 3;
//let c = 2;
//let d = a <= 0 && b >= 0 && c >= 0;
//let t = (b**2 - 4*a*c) > 0;
//console.log(t);


//Boolean 25;
//let x = -3;
//let y = 4;
//let t = x*y < 0;
//console.log(t);


//Boolean 26;
//let x = 6;
//let y = -3;
//let d = x*y < 0;
//console.log(d);


//Boolean 27;
//let x = -3;
//let y = 5;
//let x1 = -5;
//let y1 = -2;
//let d = x*y < 0 || x1*y1 > 0;
//console.log(d);


//Boolean 28;
//let x = 4;
//let y = 5;
//let x1 = -3;
//let y1 = -5;
//let d = x*y > 0 || x1*y1 > 0;
//console.log(d);


//Boolean 29;
//let x = 3;
//let y = 5;
//let x1 = 1;
//let y1 = 7;
//let x2 = 5;
//let y2 = 7;
//let k = x1 <= x <= x2 && y1 <= y <= y2;
//console.log(k);


//Boolean 30;
//let a = 3;
//let b = 3;
//let c = 3;
//let k = a +b > c || a + c > b || b + d > a;
//let d = a == b || a == c || b == c;
//console.log(d);


//Boolean 31;
//let a = 4;
//let b = 6;
//let c = 4;
//let k = a + b > c || a + c > b || b + d > a;
//let d =  a == c || a == c != b;
//console.log(d);


//Boolean 32;
//let a = 3;
//let b = 4;
//let c = 5;
//let d = a + b > c || a + c > b || b + c > a;
//let k = c**2 == a**2 + b**2;
//console.log(k);


//Boolean 33;
//let a = 3;
//let b = 7;
//let c = 9;
//let d = a + b > c || a +c > b || c + b > a;
//console.log(d);


//Boolean 34;
//let x = 5;
//let y = 7;
//let qora = (x + y) % 2 == 0;
//console.log(qora);


//Boolean 35;
//let x = 3;
//let y = 1;
//let x1 = 7;
//let y1 = 5;
//let qora= (x + y) % 2 == 0 || (x1 + y1) % 2 == 0;
//console.log(qora);


//Boolean 36;
// let x = 3;
// let y = 5;
// let x1 = 3;
// let y1 = 6;
// let d = (x==x1) && y != y1 || y == y2 && x != x1;
// console.log(d);


//Boolean 37;
//let x = 2;
//let y = 3;
//let x1 = 6;
//let y1 = 3;
//let d =(x + y) % 2 ==1 || 
//(x1 + y1) % 2 == 1 ||
//(x + y) % 2 == 0 ||
//(x1 + y1) % 2 == 0;
//console.log(d);


//Boolean 38;
//let x = 5;
//let y = 6;
//let x1 = 5;
//let y1 = 8;
//let d = (x +y) % 2 ==1 || 
//(x1 +y1) % 2 ==1 ||
//(x + y) % 2 == 0 ||
//(x1 + y1) % 2 == 0;
//console.log(d);


//Boolean 39;
//let x = 3;
//let y = 4;
//let x1 = 7;
//let y1 = 8;
//let d = (x + y) % 2 ==1 || 
//(x1 + y1) % 2 ==1 ||
//(x + y) % 2 == 0 ||
//(x1 + y1) % 2 == 0;
//console.log(d);


//Boolean 40;
// let x = 4;
// let y = 5;
// let x1 = 4;
// let y1 = 7;
// let d = (x + y) % 2 ==1 || 
//(x1 + y1) % 2 ==1 ||
//(x + y) % 2 == 0 ||
//(x1 + y1) % 2 == 0;
//console.log(d);




