// for 1;
// let k = 3;
// let n = 3;
// for (i = 1; i <= n; i++){
//     console.log(k);
// }



//for 2;
// let a = 4;
// let b = 8;
// let s = 0;
// for(let i = a; i <= b; i++){
//     console.log(i);
//     s++;
// }
// console.log(s);



//for 3;
// let a = 7;
// let b = 13;
// let s = 0;
// for(let i = a + 1; i < b; i++){
//     console.log(i);
//     s++;
// }
// console.log(s);



//for 4;
// let a = 10;
// // 1 kg narxi;
// let s = 1000;
// let k;
// for(let i = 1; i <= a; i++){
//     k = i*s;
//     console.log(k);
// }



//for 5;
// let a = 1;
// let k = 1000;
// let s;
// for(let i = 0.1; i <= a; i +=0.1){
//     s = i*k;
//     console.log(+s.toFixed(6));
// }



//for 6;
// let a = 2;
// let k = 1000;
// let s;
// for(let i = 1.2; i <= 2; i += 0.2){
//     s = i*k;
//     console.log(+s.toFixed(10));
// }



//for 7;
// let a = 1;
// let b = 9;
// let s = 0;
// for(let i = a; i <= b; i += 1){
//     s += i;
// }
// console.log(s);



//for 8;
// let a = 1;
// let b = 5;
// let s = 1;
// for(let i = a; i <= b; i += 1){
//     s *= i;
// }
// console.log(s);



//for 9;
// let a = 1;
// let b = 4;
// let s = 0;
// for(let i = a; i <= b; i += 1){
//     s += i*i;
// }
// console.log(s);



//for 10;
// let b = 3;
// let s = 0;
// for(let i = 1; i <= b; i += 1){
//     s += 1 / i;
// }
// console.log(s);



//for 11;
// let a = 5;
// let s = 0;
// for(let i = 1; i <= a; i += 1){
//     s += i*i;  
// }
// console.log(s);



//for 12;
// let a = 2;
// let s = 1;
// for(let i = 1; i <= a; i++){
//     s *= 1 + (i / 10);
// }
// console.log(s); 



//for 13;
// let n = 2;
// let s = 0;
// let p = 1;
// let k = 0;
// for(let i = 1; i <= n; i++){
//     s += p*(1+(i / 10));
//     p *= -1;
// }
// console.log(+s.toFixed(15));



//for 14;
// let n = 4;
// let s = 0;
// for(let i = 1; i <= n*n; i += 2){
//     s += i;
// }
// console.log(s);



//for 15;
// let a = 5;
// let n = 3;
// for(let i = a; i <= a; i++){
//     s = i**n;
//     console.log(s);
// }



//for 16;
// let a = 4;
// let n = 3;
// let s = 1;
// for(let i = 1; i <= n; i++){
//     s = a**i;
//     console.log(s);  
// }




//for 17;
// let a = 4;
// let n = 3;
// let s = 1;
// let p = 0;
// for(let i = 0; i <= n; i++){
//     s = a**i;
//     p += s;
//     console.log(s);  
// }
// console.log(p);



//for 18;
// let a = 4;
// let n = 3;
// let s = 1;
// let k = 1, p = 0;
// for(let i = 0; i <= n; i++){
//     s = a**i;
//     p += k*s;
//     k *= -1; 
//     console.log(s);  
// }
// console.log(p);



//for 19;
// let n = 6;
// let s = 1;
// for(i = 1; i <= n; i++){
//     s *= i;
// }
// console.log(s);




//for 20;
// let n = 4;
// let s = 1;
// let p = 0;
// for(let i = 1; i <= n; i++){
//     s *= i;
//     p += s;
// }
// console.log(p);



//for 21;
// let n = 4;
// let s = 1;
// let p = 0;
// for(let i = 1; i <= n; i++){
//     s *= i;
//     p += 1 /s;
// }
// console.log(p);



//for 22;
// let a = 2;
// let x = 2;
// let s = 1;
// let p = 1;
// for(let i = 1; i <= x; i++){
//     s *= i;
//     p += (i**i / s);
// }
// console.log(p);



//for 23;
// let n = 3;
// let x = 2;
// let f = 1;
// let d = 1;
// let pm = 1;
// let s = 0;
// for(i = 1; i <= n; i++) {
//     s += pm * x**d / f;
//     d += 2;
//     f *= 2 * i * (2 * i + 1);
//     pm *= -1;
// }
// console.log(s);




//for 24;
// let f = 1;
// let n = 2;
// let x = 3;
// let k = -1;
// let s = 1;
// for(let i = 1; i <= n; i++) {
//     f *= 2 * i * (2*i-1);
//     x += 2*i;
//     s += k*(n**i) / f;
//     k *= -1;
// }
// console.log(s);



//for 25;
// let n = 3;
// let x = 1/2;
// let s = 0;
// let p = 0;
// let k = -1;
// for(let i = 1; i <= n; i++){
//     s += i;
//     k *= -1;
//     p += k*(x**i)/i;
// }
// console.log(p);



//for 24;
// let n = 1;
// let x = 2;
// let f = 1;
// let k = -1;
// let s = 1;
// for(i = 1; i <= n; i++){
//     s += k*x / f;
//     k *= -1;
//     x *= x*x;
//     f *= 2*f*(2*f - 1);
// }
// console.log(s);



//for 26;
// let x = 1/2;
// let n = 2;
// let xn = x;
// let m = 1;
// let k = 1;
// let s = 0;
// for(let i = 1; i <= n; i++){
//     s += k*x / m;
//     k *= -1;
//     xn *= x*x;
//     m += 2;
// }
// console.log(s);




//for 27;......................................
// let n = 2;
// let x = 1/2;
// let s = 1/2;
// let d = 2;
// let k = 1;
// let p = 2;
// for(let i = 3; i <= 3; i += 2){
//     d += 2;
//     k += 2;
//     s += (k*x**i) / (d*i);
// }
// console.log(s);



//for 28;..............................
// let n = 2;
// let x = 1/2;
// let s = 1;
// let d = 2;
// let k = 1;
// let pm = 1;
// let p = 2;
// for(let i = 3; i <= 3; i += 2){
//     d += 2;
//     p *= -1;
//     k += 2;
//     s += pm*(k*x**i) / (d*(d+2));
// }
// console.log(s);



//for 29;
// let n = 2;
// let A = 5;
// let B = 19;
// let s = 0;
// let k = 0;
// for(let i = A; i <= B; i += n){
//     s = i; 
//     k++;
//     console.log(s);
// }
// console.log(k-1);



//for 30;
// let n = 5;
// let a = 3;
// let b = 10;
// let dx = (b - a) / n;
// for(let i = 0; i <= n; i++){
//     x = a + i*dx;
//     y = 1 - Math.sin(x);
//     console.log(y);
// }



//for 31; --- aka-uka usuli;
// let k = 1;
// let b = 2;
// let a;
// for(i = 1; i <= k; i++){
//     a = b;
//     b = 2 + 1 / a;
// }
// console.log(b);



//for 32;
// let k = 1;
// let b = 1;
// let a;
// for(i = 1; i <= k; i++){
//     a = b;
//     b = (1 + a) / k;
// }
// console.log(b);



// for 33;
// let k = 2;
// let a = 1;
// let b = 1;
// let c;
// for(i = 1; i <= k; i++){
//     c = a;
//     a = b;
//     b = c + a;
// }
// console.log(b);




// for 34;
// let k = 1;
// let a = 1;
// let b = 2;
// let c;
// for(i = 1; i <= k; i++){
//     c = a;
//     a = b;
//     b = (c + 2*a) / 3;
// }
// console.log(b);



// for 35;
// let k = 1;
// let a = 1;
// let b = 2;
// let c = 3;
// let s;
// for(i = 1; i <= k; i++){
//     s = a;
//     a = b;
//     b = c;
//     c = s + a - 2*b;
// }
// console.log(c);



//for 36;
// let n = 4;
// let k = 2;
// let s = 0;
// for(let i = 1; i <= n; i++){
//     s += i**k;
// }
// console.log(s);



//for 37;
// let n = 3;
// let s = 0;
// for(let i = 1; i <= n; i++){
//     s += i**i;
// }
// console.log(s);



//for 38;
// let n = 5;
// let s = 0;
// let d = n;
// for(i = 1; i <= n; i++){
//     s += i**d;
//     d -= 1;
// }
// console.log(s);



//for 39;
// let a = 2;
// let b = 4;
// let k = 0;
// for(let i = a; i <= b; i++){
//     for(let j = 1;j <= i; j++){
//         console.log(i);
//     }
// } 



//for 40;
// let a = 3;
// let b = 9;
// for(let i = a; i <= b; i++){
//     for(let j = a; j <= i; j++){
//         console.log(i);
//     }
// }



















//...................................while masalalari;


//while 1;
// let a = 11;
// let b = 3;
// while(a >= b){
//     a -= b;
// }
// console.log(a);
    

//while 2;
// let a = 9;
// let b = 2;
// let k = 0;
// while(a >= b){
//     a -= b;
//     k++;
// }
// console.log(k);



//while 3;
// let a = 7;
// let b = 2;
// let k = 0;
// while(a >= b){
//     a -= b;
//     k++;
// }
// console.log(k,a);


// while 4;
// let n = 28;
// let t = 1;
// while(t < n){
//     t *= 3;
// }
// if(t == n){
//     console.log("3 ning darajasi");
// }
// else{
//     console.log("3 ning darajasi emas");
// }



// while 5;
// let n = 256;
// let k = 0;
// let p = 1;
// while(n > p){
//     p *= 2; 
//     k++;
// }
// console.log(k);



// while 6;
// let n = 7;
// let p = 1;
// while(n > 1){
//     p *= n;
//     n -= 2;
// }
// console.log(p);



// while 7;
// let n = 27;
// let k = 1;
// while(k*k < n){
//     k++;
// }
// console.log(k);




// while 8;
// let n = 226;
// let k = 1;
// while(n >= k*k){
//     k++;
// }
// console.log(k-1);



// while 9;
// let n = 82;
// let k = 1;
// while(n > 3**k){
//     k++;
// }
// console.log(k);



// while 10;
// let n = 80;
// let k = 1;
// while(3**k <= n){
//     k++;
// }
// console.log(k-1);



// while 11;
// let n = 10;
// let k = 1;
// let s = 0;
// while(s <= n){
//     s += k;
//     k++;
// }
// console.log(k,s);



// while 12;
// let n = 16;
// let k = 1;
// let s = 0;
// while(s <= n){
//     s += k;
//     k++;
// }
// console.log(k-2,s-(k-1));




// while 13;
// let a = 2;
// let k = 1;
// let s = 0;
// while(a >= k){
//     s += 1 / k;
//     k += 1;
// }
// console.log(k,s);



//while 14;
// let a = 3;
// let k = 1;
// let s = 0;
// while(a >= k){
//     s += 1 / k;
//     k += 1;
// }
// console.log(k-1,s);



//while 15;
let s = 10000;
let p = 20;
let k = 0;
let e = s;
while(e < 2*s){
    e *= 1 + p /100;
    k++;
}
console.log(e,k);



// while 16;
// let s = 10;
// let p = 20;
// let e = s;
// let k = 0;
// while(e <= 200){
//     e *= 1+ p / 100;
//     k++;
//     console.log(+e.toFixed(1),k);
// }



// while 17;
// let n = 10;
// let m = 3;
// let s = 0;
// while(n > m){
//     n -= m;
//     s++;
// }
// console.log(s,n);



// while 18;
// let n = 123;
// let k = 0;
// while(n > 0){
//    k = k*10 + n%10;
//    n = parseInt(n / 10);
// }
// console.log(k);


// while 19;
// let n = 444;
// let k = 0;
// let s = 0;
// while(n > 0){
//    s += n%10;
//    n = parseInt(n / 10);
//    k++;
// }
// console.log(s,k);



// while 20;
// let n = 123;
// let k;
// let s = " ";
// while(n > 0){
//     k = n%10;
//     n = parseInt(n/10);
//     if(k == 2){
//         s = "bor";
//         n = -1;
//     }
//     else{
//         s = "yo'q";
//     }
// }
// console.log(s);



// while 21;
// let n = 468;
// let k;
// let s = " ";
// while(n > 0){
//     k = n%10;
//     n = parseInt(n/10);
//     if(k % 2 == 1){
//         s = "bor";
//         n = -1;
//     }
//     else{
//         s = "yo'q";
//     }
// }
// console.log(s);



// while 22;.................................;
// let n = 361;
// let s = " ";
// if((n%2==0||n%3==0||n%5==0) &&n!=2&&n!=3) {
//     console.log("m  son");
// }
// else {
//     console.log("t son");
// }
// console.log(s);



// while 23;.........................;



// while 24;
// let n = 4;
// let a = 1;
// let b = 1;
// let c;
// while(a < n){
//     c = b;
//     b = a;
//     a = c + b;
// }
// if(a == n){
//     console.log("bor");
// }
// else{
//     console.log("yo'q");
// }



// while 25;
// let n = 4;
// let a = 1;
// let b = 1;
// let c;
// while(a < n){
//     c = b;
//     b = a;
//     a = c + b;
// }
// if(a == n){
//     console.log(a+1);
// }
// else{
//     console.log("yo'q");
// }



// while 26;
// let n = 5;
// let a = 1;
// let b = 1;
// let c;
// while(a < n){
//     c = b;
//     b = a;
//     a = c + b;
// }
// if(a == n){
//     console.log(a-1,a+1);
// }
// else{
//     console.log("yo'q");
// }



// while 27;
// let n = 5;
// let a = 1;
// let s = 2;
// let b = 1;
// let c;
// while(b < n){
//     c = a;
//     a = b;
//     b = c + a;
//     s++;
// }
// if(b == n){
//     console.log(s);
// }
// else{
//     console.log("bunday had yo'q");
// }



// while 28;............
// let e = 4;
// let a = 2,k=1;
// let b;
// while(!(b-a<e)){
//     a = b;
//     b = 2 + 1 / a;
//     k++;
// }
//     console.log(k,b,a);


// while 30;
// let A = 3,B = 4, C = 2, K1 = 0,K2 = 0,S;
// while(C<=A){
//     A -= C;
//     K1++;
// }
// while(C<=B){
//     B -= C;
//     K2++;
// }
// S = K1*K2;
// console.log(S);



