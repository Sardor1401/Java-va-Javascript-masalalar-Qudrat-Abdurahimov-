//if 1;
//let a = 5;
//if(a > 0){
//   a += 1;
//}
//console.log(a);


//if 2;
//let a = 6;
//if(a > 0) {
//    a = a +1;
//}
//else{
//    a = a - 2;
//}
//console.log(a);


//if 3;
//let a = 8;
//if(a > 0) {
//    a = a + 1;
//}
//else if(a < 0) {
//a = a-2;
//}
//else if(a == 0){
//    a = 10;
//}
//console.log(a);


//if 4;
//let a = 4, b = -3, c = 6;
//let s = 0;
//if(a > 0) {
//    s += 1;
//}
//
//if(b > 0) {
//  s += 1;
//}

// if(c > 0) {
//     s += 1;
// }
// console.log(s);


//if 5;
// let a = 5;
// let b = -2;
// let c = -5;
// let s = 0, k = 0;
// if(a > 0) {
//     s += 1;
// }

// else if(a < 0){
//     k += 1; 
// }

// if(b > 0) {
//     s += 1;
// }

// else if(b < 0) {
//     k += 1;
// }

// if(c > 0) {
//     s += 1;
// }

// else if(c < 0) {
//     k += 1;
// }
// console.log(s,k);


//if 6;
// let a = 7;
// let b = 9;
// if(a > b) {
//     s = a;
// }
// else if(b > a) {
//     s = b;
// }
// console.log(s);


//if 7;
// let a = 5;
// let b = 8;

// if(a > b) {
//     s = b;
// }

// else if(a < b) {
//     s = a;
// }
// console.log(s);


//if 8;
// let a = 9;
// let b = 7;
// if(a > b) {
//     s = a;
//     k = b;
// }
// else if(a < b) {
//     s = b;
//     k = a;
// }
// console.log(s,k);


//if 9;
// let a = 12;
// let b = 9;
// let s = 0;
// if(a > b) {
//     s = b + " " + a;
// }

// else if(b > a){
//     s = a + " " + b;
// }
// console.log(s);


//if 10;
// let a = 9;
// let b = 6;
// if(a != b) {
//   k = a + b;
// }
// else if(a == b){
//     k = 0;
// }
// console.log(k);


//if 11;
// let a = 1;
// let b = 3;
// if(a != b, a < b) {
//     s = b;
// } 
// else if(a != b, a > b) {
//     s = a;
// }
// else if(a == b) {
//     s = 0;
// }
// console.log(s);


//if 12;
// let a = 28, b = 40, c = 100;
// if(a < b && b < c && a < c || a < c && c < b && a < b) {
//     s = a;
// }
// if( c < a && c < b && a < b || c < b && b < a && c < a ) {
//     s = c;
// }
// if(b < a && a < c && b < c || b < c && c < a && b < a) {
//     s = b;
// }
// console.log(s);

//if 13;
// let a = 111;
// let b = 68;
// let c = 77;
// if((a < b && b < c) || (c < b && b < a) ) {
//     k = b;
// }
// if((b < a && a < c) || (c < a && a < b)) {
//     k = a;
// }
// if((a < c && c < b) || (b < c && c < a)) {
//     k = c;
// }
// console.log(k);


//if 14;
// let a = 12;
// let b = 8;
// let c = 9;
// if(a < b && b < c && a < c) {
//     k = a;
//     s = c;
// }
// if(b < a && a < c && b < c) {
//     k = b;
//     s = c
// }
// if(a < c && c < b && a < b) {
//     k = a;
//     s = b;
// }
// if(c < b && b < a && c < a) {
//     k = c;
//     s = a;
// }
// if(c < a && a < b && c < b) {
//     k = c;
//     s = b;
// }
// if(b < c && c < a && b < a) {
//     k = b;
//     s = a;
// }
// console.log(k,s);


//if 15;
// let a = 14;
// let b = 9;
// let c = 6;
// if(a < b && b < c && a < c) {
//     s = b;
//     k = c;
// }
// if(a < c && c < b && a < b) {
//     s = c;
//     k = b;
// }
// if(b < a && a < c && b < c) {
//     s = a;
//     k = c;
// }
// if(b < c && c < a && b < a) {
//     s = c;
//     k = a;
// }
// if(c < a && a < b && c < b) {
//     s = a;
//     k = b;
// }
// if(c < b && b < a && c < a) {
//     s = b;
//     k = a;
// }
// console.log(s,k);



//if 16;
// let a = 30;
// let b = 12;
// let c = 5;
// if(a < b && b < c && a < c || a < c && c < b && a < b || b < a && a < c && b < c || 
//     b < c && c < a && b < a || c < a && a < b && c < b || c < b && b < a && c < a) {
//     s1 = 2*a;
//     s2 = 2*b;
//     s3 = 2*c;
// }
// else {
//     s1 = -a;
//     s2 = -b;
//     s3 = -c;
// }
// console.log(s1,s2,s3);


//if 17;
// let a = 8;
// let b = 80;
// let c = 12;
// if(a < b && b < c && a < c || c > a && c > b && b > a || a < c && c < b && a < b || b > a && b > c && c > a 
// || b < a && a < c && b < c || c > b && c > a && a > b || b < c && c < a && b < a || a > b && a > c && c > b ||
// c < a && a < b && c < b || b > c && b > a && a > c || c < b && b < a && c < a || a > c && a > b && b > c ) {
//     s1 = 2*a
//     s2 = 2*b
//     s3 = 2*c
// }
// else {
//     s1 = -a;
//     s2 = -b;
//     s3 = -c;
// }
// console.log(s1,s2,s3);


//if 18;
// let a = 7, b = 8; c = 7;
// if(a == b) {
//     k = c;
// }
// if(b == c) {
//     k = a;
// }
// if(a == c) {
//     k = b;
// }
// console.log(k);


//if 19;
// let a = 4, b = 4, c = 4, d = 6;
// if(a == b && b == c) {
//     k = d;
// }
// if(a == d && d == b) {
//     k = c;
// }
// if(b == c && c == d) {
//     k = a;
// }
// if(a == c && c == d) {
//     k = b;
// }
//  console.log(k);


//if 20;
// let a = 9, b = 13, c = 12;
// if(a > b) {
//     k = a + b;
// }
// if(a < c) {
//     k = a + c;
// }
// console.log(k);


//if 21;
// let x = 4, y = - 7;
// if(x = 0, y < 0, y > 0) {
//     k = 1;
// }
// else if(y = 0, x > 0, x < 0) {
//     k = 2;
// }
// else {
//     k = 3;
// }
// console.log(k);


//if 22;
// let x = -2, y = 8;
// if(x > 0, y > 0) {
//     k = 1;
// }
// if(x < 0, y > 0) {
//     k = 2;
// }
// if(x < 0, y < 0) {
//     k = 3;
// }
// if(x > 0, y < 0) {
//     k = 4;
// }
// console.log(k);


//if 23;
// let x = 6, y = 8, x1 = 6, y1 = 2, x3 = 2, y3 = 2;
// if(x = x1, y = y3) {
//     x4 = 2, y4 = 8;
// }
// console.log(x4,y4);


//if 24;
// let x = -5;
// if(x > 0) {
//     k = 2*sin(x);
// }
// if(x <= 0) {
//     k = x - 6;
// }
// console.log(k);


//if 25;
// let x = 5;
// if(x < -2 || x > 2) {
//     k = 2*x;
// }
// else {
//     k = -3*x;
// }
// console.log(k);


//if 26;
// let x = 8;
// if(x <= 0) {
//     k = -x;
// }
// if(x > 0 && x < 2) {
//     k = x**2;
// }
// if( x >= 2) {
//     k = 4;
// }
// console.log(k);


//if 27;
// let x = 9.3;
// if(x < 0) {
//     k = 0;
// }
// if(Math.floor(x) % 2 == 0) {
//     k = 1;
// }
// else {
//     k = -1;
// }
// console.log(k);


//if 28;
// let x = 2304;
// if(x % 4 == 0 && x % 400 == 0) {
//     x;
//     s = "kabisa yili"
// }
// else{
//     x;
//     s = "kabisa yili emas"
// }
// console.log(x,s);


//if 29;
// let x = 197;
// if(x > 0 && x % 2 == 0) {
//     k = x;
//     s = "musbat juft son";
// }
// if(x > 0 && x % 2 == 1) {
//     k = x;
//     s = "musbat toq son";
// }
// if(x < 0 && x % 2 == 1) {
//     k = x;
//     s = "manfiy toq son";
// }
// if(x < 0 && x % 2 == 0) {
//     k = x;
//     s = "manfiy juft son";
// }
// if(x == 0){
//     k = x;
//     s = "bu son nolga teng"
// }
// console.log(k,s);


//if 30;
// let x = 333;
// if(x > 0 && x % 2 == 0 && x < 100) {
//     k = x;
//     s = "bu son ikki xonali juft son";
// }
// if(x > 0 && x % 2 == 1 && x < 100) {
//     k = x;
//     s = "bu son ikki xonali toq son"
// }
// if(x > 0 && x % 2 == 0 && x < 10) {
//     k = x;
//     s = "bu son bir xonali juft son";
// }
// if(x > 0 && x % 2 == 1 && x < 10) {
//     k = x;
//     s = "bu son bir xonali toq son";
// }
// if(x > 0 && x % 2 == 0 && x < 1000) {
//     k = x;
//     s = "bu son uch xonali juft son";
// }
// if(x > 0 && x % 2 == 1 && x < 1000) {
//     k = x;
//     s = "bu son uch xonali toq son";
// }
// console.log(k,s);



