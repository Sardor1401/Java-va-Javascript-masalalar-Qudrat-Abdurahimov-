//Integer 1;
//let a = parseInt("5000");
//let b =parseInt(a / 100);
//console.log(b);

//Integer 2;
//let m = parseInt("34527");
//let k = parseInt(m / 1000);
//console.log(k);

//Integer 3;
//let a = parseInt("76543");
//let b = parseInt(a / 1024);
//console.log(b);

//Integer 4;
//let a = 35;
//let b = 6;
//let c = parseInt(a / b)*b;
//console.log(c);

//Integer 5;
//let a = 46;
//let b = 7;
//let c = parseInt(a / b)*b;
//let k = parseInt(a - c);
//console.log(c,k);

//Integer 6;
//let a = 19;
//let b = parseInt(a / 10);
//let c = parseInt(a % 10);
//console.log(b,c);

//Integer 7;
//let a = 35;
//let b = parseInt(a / 10);
//let c = parseInt(a % 10);
//let k = parseInt(b + c);
//console.log(k);

//Integer 8;
//let a = 67;
//let b = parseInt(a / 10);
//let c = parseInt(a % 10);
//let k = c*10+b;
//console.log(k);

//Integer 9;
//let a = 568;
//let b = parseInt(a / 100);
//console.log(b);

//Integer 10;
//let a = 624;
//let b = parseInt(a % 10);
//let c = parseInt(a / 10)%10;
//console.log(b,c);

//Integer 11;
//let a = 897;
//let b = parseInt(a / 100);
//let c = parseInt(a / 10)%10;
//let k = parseInt(a % 10);
//let m = parseInt(b + c + k);
//console.log(m);

//Integer 12;
//let a = 378;
//let b = parseInt(a / 100);
//let c = parseInt(a / 10)%10;
//let k = parseInt(a % 10);
//let m = k*100+c*10+b;
//console.log(m);

//Integer 13;
//let a = 156;
//let b = parseInt(a / 100);
//let c = parseInt(a % 10);
//let k = parseInt(a / 10)%10;
//let m = k*100 + c*10 + b;
//console.log(m); 

//Integer 14;
//let a = 326;
//let b = parseInt(a % 10);
//let c = parseInt(a / 10);
//let m = b*100 + c;
//console.log(m);

//Integer 15;
//let a = 123;
//let b = parseInt(a / 100);
//let c = parseInt(a / 10)%10;
//let k = parseInt(a % 10);
//let m = c*100 + b*10 + k;
//console.log(m);

//Integer 16;
//let a = 123;
//let b = parseInt(a / 100);
//let c = parseInt(a / 10)%10;
//let k = parseInt(a % 10);
//let m = b*100 + k*10 + c;
//console.log(m);

//Integer 17;
//let a = 1324;
//let b = parseInt(a / 100)%10;
//console.log(b);

//Integer 18;
//let a = 7653;
//let b = parseInt(a / 1000);
//console.log(b);

//Integer 19;
//let a = 9856;
//let b = parseInt(a / 60);
//console.log(b);

//Integer 20;
//let a = 3902;
//let b = parseInt(a / 3600);
//console.log(b);

//Integer 21;
//let a = 389;
//let b = parseInt(a / 60);
//let c = parseInt(a % 60);
//console.log(b,c);

//Integer 22;
//let a = 7643;
//let b = parseInt(a / 3600);
//let c = parseInt(a % 60);
//console.log(b,c);

//Integer 23;
//let a = 4982;
//let b = parseInt(a / 3600);
//let c = parseInt(a / 60);
//let k = parseInt(a % 60);
//console.log(b,c,k);

//Integer 24;
//let k = 330;
//let c = parseInt(k % 7);
//console.log(c);

//Integer 25;
//let a = 258;
//let b = parseInt((a % 7) + 3)%7;
//console.log(b);

//Integer 26;
//let a = 197;
//let b = parseInt((a % 7) + 1);
//console.log(b);

//Integer 27;
//let a = 279;
//let b = parseInt((a % 7) + 1);
//console.log(b);

//Integer 28;
//let n = 7;
//let k = 297;
//let c = (k + (n + 5)%7 +1)%7;
//console.log(c);

//Integer 29;
//let a = 10;
//let b = 35;
//let c = 8;
//let t = parseInt(a*b);
//let m = parseInt(c**2);
//let n = parseInt(t / m);
//let s = parseInt(t - 5*m);
//console.log(n,s);

//Integer 30;
//let a = 1786;
//let b = parseInt((a / 100) + 1);
//console.log(b);

