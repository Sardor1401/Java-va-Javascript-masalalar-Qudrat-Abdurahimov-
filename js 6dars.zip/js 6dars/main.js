//Case 1;
// let haftaKuni = 6;
// let haftaSuzda;

// switch(haftaKuni){
//     case 1:{
//         haftaSuzda = "Dushanba";
//     } break;
//     case 2: {
//         haftaSuzda = "Seshanba";
//     } break;
//     case 3: {
//         haftaSuzda = "Chorshanba";
//     } break;
//     case 4: {
//         haftaSuzda = "Payshanba";
//     } break;
//     case 5: {
//         haftaSuzda = "Juma";
//     } break;
//     case 6: {
//         haftaSuzda = "Shanba";
//     } break;
//     case 7: {
//         haftaSuzda = "Yakshanba";
//     }

//     default: {
//         haftaSuzda = "Bunday hafta kuni yoq";
//     }
// }
// console.log(haftaSuzda);



//Case 2;
// let bahoSuzda = 6;
// let baho;
// switch(bahoSuzda){
//     case 1: {
//         baho = "yomon";
//     }break;

//     case 2: {
//         baho = "qoniqarsiz";
//     }break;

//     case 3: {
//         baho = "qoniqarli";
//     }break;

//     case 4: {
//         baho = "yaxshi";
//     }break;
//     case 5: {
//         baho = "a'lo";
//     }break;

//     default:{
//         baho = "xato";
//     }break;
// }
// console.log(baho);



//Case 3;
// let sana = 11;
// let oyNomi;
// switch(sana) {
//     case 12 : case 1:case 2: {
//         oyNomi = "Qish";
//     }break;

//     case 3: case 4: case 5: {
//         oyNomi = "Bahor";
//     }break;

//     case 6: case 7: case 8: {
//         oyNomi = "Yoz";
//     }break;

//     case 9: case 10: case 11: {
//         oyNomi = "Kuz";
//     }break;


//     default: {
//         oyNomi = "xato";
//     }break;


// }
// console.log(oyNomi);



//Case 4;
// let raqam = 2;
// let oy;
// switch(raqam) {
//     case 1: case 3: case 5:case 7:case 8: case 10: case 12:{
//         oy = "31";
//     }break;

//     case 2:{
//         oy = "28";
//     }break;

//     case 4: case 6: case 9: case 11: {
//         oy = "30";
//     }break;

//     default: {
//         oy = "xato";
//     }break;

// }
// console.log(oy);


//Case 5;
// let a = 8;
// let b = 8;
// let haqiqiySonlar = 4; 
// let shart;
// switch(haqiqiySonlar){
//     case 1: {
//         shart = a + b;
//     }break;

//     case 2: {
//         shart = a - b;
//     }break;

//     case 3: {
//         shart = a / b;
//     }break;

//     case 4: {
//         shart = a * b;
//     }break

//     default: {
//         shart = "xato";
//     }

// }
// console.log(shart);



//Case 6;
// let a = 150;
// let haqiqiySon = 5;
// let uzunlik;

// switch(haqiqiySon) {
//     case 1: {
//         uzunlik = a / 10;
//     }break;

//     case 2: {
//         uzunlik = a * 1000;
//     }break;

//     case 3: {
//         uzunlik = a;
//     }break;

//     case 4: {
//         uzunlik = a / 1000;
//     }break;

//     case 5: {
//         uzunlik = a / 100;
//     }break;

//     default:{
//         uzunlik = "xato";
//     }break;

// }
// console.log(uzunlik);




//Case 7;
// let a = 1500;
// let ogirlik = 5;
// let birlikar;
// switch(ogirlik) {
//     case 1 : {
//         birlikar = a;
//     }break;

//     case 2 : {
//         birlikar = a / 1000000;
//     }break;

//     case 3: {
//         birlikar = a / 1000;
//     }break;

//     case 4 : {
//         birlikar = a * 1000;
//     }break;

//     case 5 : {
//         birlikar = a * 100;
//     }break;

//     default:{
//         birlikar = "xato";
//     }break;

// }
// console.log(birlikar);


//Case 8;......................




//Case 9;
// let d = 31;
// let m = 12;
// if(d == 28 && m == 2){
//     d = 1;
//     m += 1;
// }
// else if(d == 30) {
//     switch (m) {
//         case 4: case 6: case 9: case 11: {
//             d = 1;
//             m += 1;
//         }break;
//         default: {
//             d += 1;
//         }break;
//     }
// }
// else if(d = 31) {
//     switch (m) {
//         case 1: case 3: case 5: case 7: case 8: case 10:{
//             d = 1;
//             m += 1;
//         }break;
//     }
// }
// else if(d == 31 || m == 12){
//     switch (m) {
//         case 12: {
//             d == 1;
//             m == 1;
//         }break;
//     }
// }
// console.log(d,m);



//Case 10;
// let yunalish = 2, buyruq = 0, s,j,q,g,b,h;
// let shart;
// let bajar;
// switch(yunalish) {
//     case 1: {
//         h = "shimol";
//     }break;

//     case 2: {
//         h = "janub";
//     }break;

//     case 3: {
//         h = "sharq";
//     }break;

//     case 4: {
//         h = "g'arb";
//     }break;
// }
// switch(buyruq) {
//     case 0 : {
//         b = "harakatni davom ettir";
//     }break;

//     case 1 : {
//         b = "chapga buril";
//     }break;

//     case 2 : {
//         b = "o'nga buril";
//     }break;
// }
// console.log(h,b);




//Case 11;
// let c = 'g';
// let k1 = 1, k2 = 2;
// // birinchi kamanda ;
// switch(c){
//     case 's': {
//         switch(k1){
//             case 0: {
//                 c = 'q';
//             }break;
//             case 1:{
//                 c = 'g';
//             }break;
//             case 2: {
//                 c = 'j';
//             }break;
//         }
//     }break;
//     case 'g':{
//         switch(k1){
//             case 0: {
//                 c = 's';
//             }break;
//             case 1:{
//                 c = 'j';
//             }break;
//             case 2: {
//                 c = 'q';
//             }break;
//         }
//     }break;
//     case 'q': {
//         switch (k1){
//             case 0 : {
//                 c = 'j';
//             }break;
//             case 1: {
//                 c = 's';
//             }break;
//             case 2: {
//                 c = 'g';
//             }break;
//         }
//     }break;
//     case 'j':{
//         switch (k1){
//             case 0 : {
//                 c = 'g';
//             }break;
//             case 1: {
//                 c = 'q';
//             }break;
//             case 2: {
//                 c = 's';
//             }break;
//         }
//     }break;
// }
// // ikkinchi kamanda;
// switch(c){
//     case 's': {
//         switch(k2){
//             case 0:{
//                 c = 'q';
//             }break;
//             case 1: {
//                 c = 'g';
//             }break;
//             case 2: {
//                 c = 'j';
//             }break;
//         }
//     }break;
//     case 'g':{
//         switch(k2){
//             case 0 : {
//                 c = 's';
//             }break;
//             case 1: {
//                 c = 'j';
//             }break;
//             case 2: {
//                 c = 'q';
//             }break;
//         }
//     }break;
//     case 'j': {
//         switch(k2){
//             case 0: {
//                 c = 'g';
//             }break;
//             case 1: {
//                 c = 'q';
//             }break;
//             case 2: {
//                 c = 's';
//             }break;
//         }
//     }break;
//     case 'q': {
//         switch(k2){
//             case 0: {
//                 c = 'j';
//             }break;
//             case 1: {
//                 c = 's';
//             }break;
//             case 2: {
//                 c = 'g';
//             }break;
//         }
//     }break;
// }
// console.log(c);



//Case 12;
// let radius;
// let diametr;
// let yuzi;
// let uzunligi = 1;
// let p = 3.14;
// let r;
// let s;
// let l = 8;
// let d;
// switch(radius) {
//     case 1: {
//         k1 = 2*r;
//         k2 = 2*p*r;
//         k3 = p*r**2;
//     }break;
// }
// switch(diametr) {
//     case 1 : {
//         k1 = d / 2;
//         k2 = p*d;
//         k3 = p*(d/2)**2;
//     }break;
// }
// switch(yuzi) {
//     case 1 : {
//         k1 = (s / p)**1/2;
//         k2 = 2*p*(s / p)**1/2;
//         k3 = 2*(s / p)**1/2;
//     }break;
// }
// switch(uzunligi) {
//     case 1 : {
//         k1 = l / (2*p);
//         k2 = l / p;
//         k3 = p*(l / (2*p))**2;
//     }break;
// }

// console.log(k1,k2,k3);



//Case 13;
// let a,S,h = 4,c;
// let gipotenuza;
// let balandlik = 'h';
// let yuzi;
// let katet;
// switch(katet){
//     case 'a':{
//         k1 = a*2**(1/2);
//         k2 = k1 / 2;
//         k3 = (k1*k2) / 2;
//     }break;
// }
// switch(gipotenuza){
//     case 'c': {
//         k1 = c / 2**(1/2);
//         k2 = c / 2;
//         k3 = c*k2/2;
//     }break;
// }
// switch(yuzi){
//     case 'S': {
//         k1 = (2*S) / (h*2**(1/2));
//         k2 = 2*S / h;
//         k3 = 2*S / k2;
//     }break;
// }
// switch(balandlik){
//     case 'h':{
//         k1 = (2*h) / (2**(1/2));
//         k2 = 2*h;
//         k3 = k2*h/2;
//     }break;
// }
// console.log(k1,k2,k3);




//Case 14;
// let a,R1,R2,S = 7;
// let tomoni;
// let yuzi = 'S';
// let Iradius;
// let Tradius;
// switch(tomoni){
//     case 'a':{
//         k1 = (a*3**(1/2)) / 6;
//         k2 = 2*k1;
//         k3 = (a**2*3**(1/2)) / 4;
//     }break;
// }
// switch(Iradius){
//     case 'R1':{
//         k1 = 6*R1 / (3**1/2);
//         k2 = k1*(3**1/2) / 3;
//         k3 = (k1**2*3**1/2) / 4;
//     }break;
// }
// switch(Tradius){
//     case 'R2':{
//         k1 = 3*R2 / 3**1/2;
//         k2 = R2 / 2;
//         k3 = (k1**2*3**1/2) / 4;
//     }break;
// }
// switch(yuzi){
//     case 'S':{
//         k1 = (4*S / 3**1/2)**1/2;
//         k2 = (k1*3**1/2) / 6;
//         k3 = 2*k2;
//     }break;
// }
// console.log(k1,k2,k3);



//Case 15;
// let N = 12;
// let M = 1;
// let s;
// let k;
// switch(M){
//     case 1: s = 'gisht'; break;
//     case 2: s = 'olma'; break;
//     case 3: s = 'chilak'; break;
//     case 4: s = 'qarga'; break;
// }
// switch(N){
//     case 6:{
//         k = 'olti ' + s;
//     }break;
//     case 7:{
//         k = 'yetti ' + s;
//     }break;
//     case 8:{
//         k = 'sakkiz ' + s;
//     }break;
//     case 9: {
//         k = 'toqqiz ' + s;
//     }break;
//     case 10: {
//         k = 'on ' + s;
//     }break;
//     case 11: {
//         k = 'valet ' + s;
//     }break;
//     case 12:{
//         k = 'dama ' + s;
//     }break;
//     case 13: {
//         k = 'qirol ' + s;
//     }break;
//     case 14: {
//         k = 'tuz ' + s;
//     }break;
// }
// console.log(k);



// Case 16;
// let a = 70;
// let k = a % 10;
// let m = parseInt(a / 10);
// if(a >= 20 && a <= 69){
//     switch(k){
//         case 1: k = 'bir yosh';break;
//         case 2: k = 'ikki yosh';break;
//         case 3: k = 'uch yosh';break;
//         case 4: k = 'tort yosh';break;
//         case 5: k = 'besh yosh';break;
//         case 6: k = 'olti yosh';break;
//         case 7: k = 'yetti yosh';break;
//         case 8: k = 'sakkiz yosh';break;
//         case 9: k = 'toqqiz yosh';break;
//         case 0: k = 'yosh';break;
//     }
//     switch(m){
//         case 1: k1 = 'on';break;
//         case 2: k1 = 'yigirma';break;
//         case 3: k1 = 'ottiz';break;
//         case 4: k1 = 'qirq';break;
//         case 5: k1 = 'ellik';break;
//         case 6: k1 = 'oltmish';break;
//     }
// }
// console.log( k1 + ' ' + k);



//Case 17;
// let a = 30;
// let k = a % 10;
// let m = parseInt(a / 10);
// switch(k){
//     case 1: k = "bitta masala";break;
//     case 2: k = "ikkita masala";break;
//     case 3: k = "uchta masala";break;
//     case 4: k = "to'rtta masala";break;
//     case 5: k = "beshta masala";break;
//     case 6: k = "oltita masala";break;
//     case 7: k = "yettita masala";break;
//     case 8: k = "sakkizta masala";break;
//     case 9: k = "to'qqizta masala";break;
//     case 0: k = "ta masala";break;
// }
// switch(m){
//     case 1: m = "o'n";break;
//     case 2: m = "yigirma";break;
//     case 3: m = "o'ttiz";break;
//     case 4: m = "qirq";break;
// }
// console.log(m + '' + k);





//Case 18;
// let son = 100;

// let yuzlar = parseInt(son / 100);
// let onlar = parseInt(son / 10) % 10;
// let birlar = son % 10;

// let s = '';

// switch(yuzlar){
//     case 1: s += 'bir '; break;
//     case 2: s += 'ikki '; break;
//     case 3: s += 'uch '; break;
//     case 4: s += 'tort '; break;
//     case 5: s += 'besh '; break;
// }
// s += "yuz ";

// switch(onlar){
//     case 1: s+= "o'n "; break;
//     case 2: s+= "yigirma "; break;
//     case 3: s+= "o'ttiz "; break;
//     case 4: s += "qirq";break;
//     case 5: s += "ellik";break;
//     case 6: s += "oltmish";break;
//     case 7: s += "yetmish";break;
//     case 8: s += "sakson";break;
//     case 9: s += "to'qson";break
// }

// switch(birlar){
//     case 1: s += "bir"; break;
//     case 2: s += "ikki"; break;
//     case 3: s += "uch"; break;
//     case 4: s += "to'rt"; break;
//     case 5: s += "besh"; break;
//     case 6: s += "olti";break;
//     case 7: s += "yetti";break;
//     case 8: s += "sakkiz";break;
//     case 9: s += "to'qqiz";break;
// }
// console.log(s);




//Case 19;....................................

// let a = 1984;
// let rang = ((a % 60) % 5);
// let hayvon  = (a % 60) % 12;
//     switch(rang){
//         case 1: rang = "yashil";break;
//         case 2: rang = "qizil";break;
//         case 3: rang = "sariq";break;
//         case 4: rang = "oq";break;
//         case 0: rang = "qora";break;
//     }
//     switch(hayvon){
//         case 1: hayvon = "sichqon yili";break;
//         case 2: hayvon = "sigir yili";break;
//         case 3: hayvon = "yo'lbars yili";break;
//         case 4: hayvon = "quyon yili";break;
//         case 5: hayvon = "ajdar yili";break;
//         case 6: hayvon = "ilon yili";break;
//         case 7: hayvon = "ot yili";break;
//         case 8: hayvon = "qo'y yili";break;
//         case 9: hayvon = "maymun yili";break;
//         case 10: hayvon = "tovuq yili";break;
//         case 11: hayvon = "it yili";break;
//         case 0: hayvon = "to'ng'iz yili";break; 
//     }

// console.log(rang + " " + hayvon);



//Case 20;
// let D = 20, M = 1;
// let burj;
// if(D >= 20 && M == 1 || D <= 18 && M == 2) {
//     burj = "Qovg'a";
// }
// else if(D >= 19 && M == 2 || D <= 20 && M == 3) {
//     burj = "Baliq";
// }
// else if(D >= 21 && M == 3 || D <= 19 && M == 4) {
//     burj = "Qo'y";
// }
// else if(D >= 20 && M == 4 || D <= 20 && M == 5) {
//     burj = "Buzoq";
// }
// else if(D >= 21 && M == 5 || D <= 21 && M == 6){
//     burj = "Egizaklar";
// }
// else if(D >= 22 && M == 6 || D <= 22 && M == 7) {
//     burj = "Qisqichbaqa";
// }
// else if(D >= 23 && M == 7 || D <= 22 && M == 8){
//     burj = "Arslon";
// }
// else if(D >= 23 && M == 8 || D <= 22 && M == 9){
//     burj = "Parizod";
// }
// else if(D >= 23 && M == 9 || D <= 22 && M == 10){
//     burj = "Tarozi";
// }
// else if(D >= 23 && M == 10 || D <= 22 && M == 11){
//     burj = "Chayon";
// }
// else if(D >= 23 && M == 11 || D <= 21 && M == 12){
//     burj = "O'qotar";
// }
// else if(D >= 22 && M == 12 || D <= 19 && M == 1){
//     burj = "Echki";
// }
// console.log(burj);



// Case 20; 2-usul;
// let D = 22, M = 7;
// let burj;
// switch(M){
//     case 1: {
//         if(D < 20){
//             burj = "Echki";
//         }
//         else{
//             burj = "Qovg'a";
//         }
//     }break;

//     case 2: {
//         if(D < 19){
//             burj = "Qovg'a";
//         }
//         else{
//             burj = "Baliq";
//         }
//     }break;

//     case 3: {
//         if(D < 20){
//             burj = "Baliq";
//         }
//         else{
//             burj = "Qo'y";
//         }
//     }break;

//     case 4: {
//         if(D < 19) {
//             burj = "Qo'y";
//         }
//         else{
//             burj = "Buzoq";
//         }
//     }break;

//     case 5: {
//         if(D < 20){
//             burj = "Buzoq";
//         }
//         else{
//             burj = "Egizaklar";
//         }
//     }break;

//     case 6: {
//         if(D < 21){
//             burj = "Egizaklar";
//         }
//         else {
//             burj = "Qisqichbaqa";
//         }
//     }break;

//     case 7: {
//         if(D < 22){
//             burj = "Qisqichbaqa";
//         }
//         else {
//             burj = "Arslon";
//         }
//     }break;

//     case 8: {
//         if(D < 22){
//             burj = "Arslon";
//         }
//         else{
//             burj = "Parizod";
//         }
//     }break;

//     case 9: {
//         if(D < 22){
//             burj = "Pariozd";
//         }
//         else{
//             burj = "Tarozi";
//         }
//     }break;

//     case 10: {
//         if(D < 23){
//             burj = "Tarozi";
//         }
//         else{
//             burj = "Chayon";
//         }
//     }break;

//     case 11: {
//         if(D < 23){
//             burj = "Chayon";
//         }
//         else{
//             burj = "O'qotar";
//         }
//     }break;

//     case 12: {
//         if(D < 22){
//             burj = "O'qotar";
//         }
//         else{
//             burj = "Echki";
//         }
//     }break;
// }
// console.log(burj);








